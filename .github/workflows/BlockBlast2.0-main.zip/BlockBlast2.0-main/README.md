# 🧩 Block Blast

Jogo estilo Block Blast criado com HTML, CSS e JavaScript.

## Como jogar

Abra:

index.html

no navegador.

## Funcionalidades

- Menu
- Níveis
- Tabuleiro
- Pontuação
- Sistema de fases
