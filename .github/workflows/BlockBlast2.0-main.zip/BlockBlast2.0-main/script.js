let nivelAtual = 1;

let score = 0;


const niveis = [

{
nome:"Fase 1",
tamanho:8,
meta:10
},

{
nome:"Fase 2",
tamanho:8,
meta:20
},

{
nome:"Fase 3",
tamanho:8,
meta:30
}

];



function abrirNiveis(){


menu.classList.add("hidden");

niveisDiv.classList.remove("hidden");


mostrarNiveis();

}



const menu=document.getElementById("menu");

const niveisDiv=document.getElementById("niveis");

const jogo=document.getElementById("jogo");



function mostrarNiveis(){


let lista=document.getElementById("listaNiveis");


lista.innerHTML="";


niveis.forEach((n,i)=>{


let botao=document.createElement("button");


botao.innerHTML=n.nome;


botao.onclick=()=> iniciar(i);


lista.appendChild(botao);


});


}




function iniciar(id){


let fase=niveis[id];


niveisDiv.classList.add("hidden");

jogo.classList.remove("hidden");


document.getElementById("fase").innerHTML=fase.nome;


criarTabuleiro();


}



function criarTabuleiro(){


let tab=document.getElementById("tabuleiro");


tab.innerHTML="";


score=0;

document.getElementById("score").innerHTML=score;



for(let i=0;i<64;i++){


let bloco=document.createElement("div");


bloco.className="bloco";


bloco.onclick=function(){


if(!bloco.classList.contains("cheio")){


bloco.classList.add("cheio");


score++;


document.getElementById("score").innerHTML=score;


verificar();

}


}



tab.appendChild(bloco);


}



}



function verificar(){


if(score>=10){


alert("🎉 Fase concluída!");

}


}




function voltar(){


menu.classList.remove("hidden");

niveisDiv.classList.add("hidden");

jogo.classList.add("hidden");


}
